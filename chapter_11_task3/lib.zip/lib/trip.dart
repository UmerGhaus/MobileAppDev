class Trip {
  String id;
  String tripName;
  String tripLocation;

  Trip({required this.id, required this.tripName, required this.tripLocation});
}